import { createContext } from 'react';
export const MemberInfoContext = createContext(null);